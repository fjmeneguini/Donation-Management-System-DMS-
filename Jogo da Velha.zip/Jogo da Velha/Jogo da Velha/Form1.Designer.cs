﻿namespace Jogo_da_Velha
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn22 = new System.Windows.Forms.Button();
            this.btn12 = new System.Windows.Forms.Button();
            this.btn02 = new System.Windows.Forms.Button();
            this.btn21 = new System.Windows.Forms.Button();
            this.btn11 = new System.Windows.Forms.Button();
            this.btn01 = new System.Windows.Forms.Button();
            this.btn20 = new System.Windows.Forms.Button();
            this.btn10 = new System.Windows.Forms.Button();
            this.btn00 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.empt = new System.Windows.Forms.Label();
            this.pontosO = new System.Windows.Forms.Label();
            this.pontosx = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.reset = new System.Windows.Forms.Button();
            this.vezde = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btn22);
            this.panel1.Controls.Add(this.btn12);
            this.panel1.Controls.Add(this.btn02);
            this.panel1.Controls.Add(this.btn21);
            this.panel1.Controls.Add(this.btn11);
            this.panel1.Controls.Add(this.btn01);
            this.panel1.Controls.Add(this.btn20);
            this.panel1.Controls.Add(this.btn10);
            this.panel1.Controls.Add(this.btn00);
            this.panel1.Location = new System.Drawing.Point(-3, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(314, 258);
            this.panel1.TabIndex = 0;
            // 
            // btn22
            // 
            this.btn22.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn22.Font = new System.Drawing.Font("Microsoft Sans Serif", 31.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn22.Location = new System.Drawing.Point(213, 175);
            this.btn22.Name = "btn22";
            this.btn22.Size = new System.Drawing.Size(99, 80);
            this.btn22.TabIndex = 8;
            this.btn22.UseVisualStyleBackColor = false;
            // 
            // btn12
            // 
            this.btn12.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn12.Font = new System.Drawing.Font("Microsoft Sans Serif", 31.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn12.Location = new System.Drawing.Point(213, 89);
            this.btn12.Name = "btn12";
            this.btn12.Size = new System.Drawing.Size(99, 80);
            this.btn12.TabIndex = 7;
            this.btn12.UseVisualStyleBackColor = false;
            // 
            // btn02
            // 
            this.btn02.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn02.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn02.Font = new System.Drawing.Font("Microsoft Sans Serif", 31.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn02.Location = new System.Drawing.Point(213, 3);
            this.btn02.Name = "btn02";
            this.btn02.Size = new System.Drawing.Size(99, 80);
            this.btn02.TabIndex = 6;
            this.btn02.UseVisualStyleBackColor = false;
            // 
            // btn21
            // 
            this.btn21.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn21.Font = new System.Drawing.Font("Microsoft Sans Serif", 31.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn21.Location = new System.Drawing.Point(108, 175);
            this.btn21.Name = "btn21";
            this.btn21.Size = new System.Drawing.Size(99, 80);
            this.btn21.TabIndex = 5;
            this.btn21.UseVisualStyleBackColor = false;
            // 
            // btn11
            // 
            this.btn11.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn11.Font = new System.Drawing.Font("Microsoft Sans Serif", 31.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn11.Location = new System.Drawing.Point(108, 89);
            this.btn11.Name = "btn11";
            this.btn11.Size = new System.Drawing.Size(99, 80);
            this.btn11.TabIndex = 4;
            this.btn11.UseVisualStyleBackColor = false;
            // 
            // btn01
            // 
            this.btn01.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn01.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn01.Font = new System.Drawing.Font("Microsoft Sans Serif", 31.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn01.Location = new System.Drawing.Point(108, 3);
            this.btn01.Name = "btn01";
            this.btn01.Size = new System.Drawing.Size(99, 80);
            this.btn01.TabIndex = 3;
            this.btn01.UseVisualStyleBackColor = false;
            // 
            // btn20
            // 
            this.btn20.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn20.Font = new System.Drawing.Font("Microsoft Sans Serif", 31.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn20.Location = new System.Drawing.Point(3, 175);
            this.btn20.Name = "btn20";
            this.btn20.Size = new System.Drawing.Size(99, 80);
            this.btn20.TabIndex = 2;
            this.btn20.UseVisualStyleBackColor = false;
            // 
            // btn10
            // 
            this.btn10.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn10.Font = new System.Drawing.Font("Microsoft Sans Serif", 31.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn10.Location = new System.Drawing.Point(3, 89);
            this.btn10.Name = "btn10";
            this.btn10.Size = new System.Drawing.Size(99, 80);
            this.btn10.TabIndex = 1;
            this.btn10.UseVisualStyleBackColor = false;
            // 
            // btn00
            // 
            this.btn00.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn00.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn00.Font = new System.Drawing.Font("Microsoft Sans Serif", 31.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn00.Location = new System.Drawing.Point(3, 3);
            this.btn00.Name = "btn00";
            this.btn00.Size = new System.Drawing.Size(99, 80);
            this.btn00.TabIndex = 0;
            this.btn00.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.empt);
            this.panel2.Controls.Add(this.pontosO);
            this.panel2.Controls.Add(this.pontosx);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(317, 15);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(173, 135);
            this.panel2.TabIndex = 1;
            // 
            // empt
            // 
            this.empt.AutoSize = true;
            this.empt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.empt.Location = new System.Drawing.Point(121, 103);
            this.empt.Name = "empt";
            this.empt.Size = new System.Drawing.Size(23, 25);
            this.empt.TabIndex = 10;
            this.empt.Text = "0";
            // 
            // pontosO
            // 
            this.pontosO.AutoSize = true;
            this.pontosO.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pontosO.ForeColor = System.Drawing.Color.Red;
            this.pontosO.Location = new System.Drawing.Point(121, 66);
            this.pontosO.Name = "pontosO";
            this.pontosO.Size = new System.Drawing.Size(23, 25);
            this.pontosO.TabIndex = 9;
            this.pontosO.Text = "0";
            // 
            // pontosx
            // 
            this.pontosx.AutoSize = true;
            this.pontosx.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pontosx.ForeColor = System.Drawing.Color.Navy;
            this.pontosx.Location = new System.Drawing.Point(121, 31);
            this.pontosx.Name = "pontosx";
            this.pontosx.Size = new System.Drawing.Size(23, 25);
            this.pontosx.TabIndex = 8;
            this.pontosx.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(11, -5);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 29);
            this.label4.TabIndex = 6;
            this.label4.Text = "PLACAR";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 25);
            this.label3.TabIndex = 5;
            this.label3.Text = "Empate:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(6, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "Jogador O:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Navy;
            this.label1.Location = new System.Drawing.Point(6, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "Jogador X:";
            // 
            // reset
            // 
            this.reset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reset.Location = new System.Drawing.Point(315, 218);
            this.reset.Name = "reset";
            this.reset.Size = new System.Drawing.Size(175, 37);
            this.reset.TabIndex = 2;
            this.reset.Text = "Resetar";
            this.reset.UseVisualStyleBackColor = true;
            this.reset.Click += new System.EventHandler(this.reset_Click);
            // 
            // vezde
            // 
            this.vezde.AutoSize = true;
            this.vezde.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.vezde.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vezde.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.vezde.Location = new System.Drawing.Point(323, 193);
            this.vezde.Name = "vezde";
            this.vezde.Size = new System.Drawing.Size(119, 18);
            this.vezde.TabIndex = 6;
            this.vezde.Text = "Vez de: Jogador X";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(490, 261);
            this.Controls.Add(this.vezde);
            this.Controls.Add(this.reset);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Jogo Da Velha";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn00;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btn22;
        private System.Windows.Forms.Button btn12;
        private System.Windows.Forms.Button btn02;
        private System.Windows.Forms.Button btn21;
        private System.Windows.Forms.Button btn11;
        private System.Windows.Forms.Button btn01;
        private System.Windows.Forms.Button btn20;
        private System.Windows.Forms.Button btn10;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button reset;
        private System.Windows.Forms.Label vezde;
        private System.Windows.Forms.Label pontosx;
        private System.Windows.Forms.Label empt;
        private System.Windows.Forms.Label pontosO;
    }
}

