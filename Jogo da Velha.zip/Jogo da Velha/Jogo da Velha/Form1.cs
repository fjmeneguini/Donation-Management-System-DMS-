﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jogo_da_Velha
{
    public partial class Form1 : Form
    {
        private string jogadorAtual = "X";
        private int pontuacaoX = 0, pontuacaoO = 0, pontuacaoEmpate = 0;
        private Button[,] tabuleiro;

        public Form1()
        {
            InitializeComponent();
            InicializarTabuleiro();
            AtualizarStatus();
        }

        private void InicializarTabuleiro()
        {
            tabuleiro = new Button[3, 3] {
            { btn00, btn01, btn02 },
            { btn10, btn11, btn12 },
            { btn20, btn21, btn22 }
        };

            foreach (Button botao in tabuleiro)
            {
                botao.Click += ClickBotao;
            }
        }

        private void ClickBotao(object sender, EventArgs e)
        {
            Button botao = (Button)sender;

            if (botao.Text == "")
            {
                botao.Text = jogadorAtual;
                if (VerificarVitoria())
                {
                    MessageBox.Show($"Jogador {jogadorAtual} venceu!");
                    if (jogadorAtual == "X") pontuacaoX++;
                    else pontuacaoO++;
                    ReiniciarPartida();
                }
                else if (VerificarEmpate())
                {
                    MessageBox.Show("Empate!");
                    pontuacaoEmpate++;
                    ReiniciarPartida();
                }
                else
                {
                    AlternarJogador();
                    AtualizarStatus();
                }
            }
            else
            {
                MessageBox.Show("Posição já ocupada!");
            }
        }

        private bool VerificarVitoria()
        {
            for (int i = 0; i < 3; i++)
            {
                if (tabuleiro[i, 0].Text == jogadorAtual && tabuleiro[i, 1].Text == jogadorAtual && tabuleiro[i, 2].Text == jogadorAtual)
                    return true;
                if (tabuleiro[0, i].Text == jogadorAtual && tabuleiro[1, i].Text == jogadorAtual && tabuleiro[2, i].Text == jogadorAtual)
                    return true;
            }

            if (tabuleiro[0, 0].Text == jogadorAtual && tabuleiro[1, 1].Text == jogadorAtual && tabuleiro[2, 2].Text == jogadorAtual)
                return true;
            if (tabuleiro[0, 2].Text == jogadorAtual && tabuleiro[1, 1].Text == jogadorAtual && tabuleiro[2, 0].Text == jogadorAtual)
                return true;

            return false;
        }

        private bool VerificarEmpate()
        {
            foreach (Button botao in tabuleiro)
            {
                if (botao.Text == "")
                    return false;
            }
            return true;
        }

        private void AlternarJogador()
        {
            jogadorAtual = (jogadorAtual == "X") ? "O" : "X";
        }

        private void AtualizarStatus()
        {
            vezde.Text = $"É a vez do jogador {jogadorAtual}";
            pontosx.Text = $"{pontuacaoX}";
            pontosO.Text = $"{pontuacaoO}";
            empt.Text = $"{pontuacaoEmpate}";
        }

        private void reset_Click(object sender, EventArgs e)
        {
            pontuacaoX = 0;
            pontuacaoO = 0;
            pontuacaoEmpate = 0;

           
            ReiniciarPartida();
        }

        private void ReiniciarPartida()
        {
            foreach (Button botao in tabuleiro)
            {
                botao.Text = "";
            }
            AtualizarStatus();
        }

        private void Resetar_Click(object sender, EventArgs e)
        {
            pontuacaoX = 0;
            pontuacaoO = 0;
            pontuacaoEmpate = 0;
            ReiniciarPartida();
        }
    }
    }